<?php
require_once(__DIR__ . "/Database.php");

class NotesModel {
  public static function createNote(Note $note) {
    $database = new Database();
    $results = $database->executeSql("INSERT INTO tblNotes (noteTitle, noteDetail, dateCreated) VALUES (?,?,?)", "sss", array($note->noteTitle, $note->noteDetail, $note->dateCreated));
    return new ModelResponse($results[0]);
  }

  public static function getNotes($noteID = null) {
    $database = new Database();
    if($noteID === null){
      $results = $database->executeSql("SELECT noteID, noteTitle, noteDetail, dateCreated FROM tblNotes");
    }
    else{
      $results = $database->executeSql("SELECT noteID, noteTitle, noteDetail, dateCreated FROM tblNotes WHERE noteID = ?", "i", array($noteID));
    }
    return new ModelResponse($results);
  }

  public static function updateNote(Note $note) {
    $database = new Database();

    $database->executeSql("UPDATE tblNotes SET noteTitle = ?, noteDetail = ?, dateCreated = ? WHERE noteID = ?", "sssi", array($note->noteTitle, $note->noteDetail, $note->dateCreated, $note->noteID));

    return new ModelResponse();
  }
  
  public static function deleteNote($noteID) {
    $database = new Database();

    $database->executeSql("DELETE FROM tblNotes WHERE noteID = ?", "i", array($noteID));

    return new ModelResponse();
  }
}

