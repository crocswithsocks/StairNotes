<?php
require_once(__DIR__ . "/Base.php");
class Note extends Base {
  public $noteID, $noteTitle, $noteDetail, $dateCreated;
  public function __construct($sourceObject) {
    parent::__construct($sourceObject);
  }
}
