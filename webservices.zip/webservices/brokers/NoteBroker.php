<?php
require_once(__DIR__ . "/../model/types/BrokerRequest.php");
require_once(__DIR__ . "/../model/types/BrokerResponse.php");
require_once(__DIR__ . "/../model/NotesModel.php");
require_once(__DIR__ . "/../model/types/ModelResponse.php");
require_once(__DIR__ . "/../model/types/Note.php");

class NoteBroker {
  static public function post(BrokerRequest $request) : BrokerResponse {
    $response = NotesModel::createNote(new Note($request->body));

    return new BrokerResponse($response->responseObject);
  }

  static public function get(BrokerRequest $request) : BrokerResponse {
    $response = NotesModel::getNotes($request->id);

    return new BrokerResponse($response->responseObject);
  }

  static public function put(BrokerRequest $request) : BrokerResponse {
    $note = new Note($request->body);
    $note->noteID = $request->id;
    $response = NotesModel::updateNote($note);

    return new BrokerResponse($response->responseObject);
  }

  static public function delete(BrokerRequest $request) : BrokerResponse {
    $noteID = $request->id;
    $response = NotesModel::deleteNote($noteID);
    
    return new BrokerResponse($response->responseObject);
  }
}